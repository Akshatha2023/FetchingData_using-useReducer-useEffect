
import './App.css'
import DataFetch from './DataFetch'

function App() {
 

  return (
    <>
      <DataFetch/>
       
    </>
  )
}

export default App
